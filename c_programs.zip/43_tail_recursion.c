/*
43 - Tail Recursion example: factorial using tail recursion
*/
#include <stdio.h>
long long tfact(int n,long long acc){ return n<=1? acc: tfact(n-1, acc*n); }
int main(){ int n; scanf("%d",&n); printf("%lld\n", tfact(n,1)); return 0; }

/*
53 - Signal handling (SIGINT)
*/
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
void h(int s){ printf("Caught signal %d\n", s); }
int main(){
    signal(SIGINT, h);
    for(int i=0;i<10;i++){ printf("%d\n", i); sleep(1); }
    return 0;
}

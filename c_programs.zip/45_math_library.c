/*
45 - Using math.h
Compile with -lm: gcc file.c -lm
*/
#include <stdio.h>
#include <math.h>
int main(){ double x; scanf("%lf",&x); printf("sqrt=%.6f sin=%.6f\n", sqrt(x), sin(x)); return 0; }

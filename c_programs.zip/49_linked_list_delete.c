/*
49 - Linked List: delete node by value
*/
#include <stdio.h>
#include <stdlib.h>
typedef struct N{ int v; struct N* next; } N;
void push(N**h,int x){ N* n=malloc(sizeof *n); n->v=x; n->next=*h; *h=n; }
void delete_val(N**h,int x){ N* cur=*h; N* prev=NULL; while(cur){ if(cur->v==x){ if(prev) prev->next=cur->next; else *h=cur->next; free(cur); return; } prev=cur; cur=cur->next; } }
void printall(N*h){ while(h){ printf("%d ",h->v); h=h->next; } printf("\n"); }
int main(){ N* head=NULL; push(&head,3); push(&head,2); push(&head,1); delete_val(&head,2); printall(head); return 0; }

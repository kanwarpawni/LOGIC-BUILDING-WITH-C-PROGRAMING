/*
27 - Basic Calculator using switch
*/
#include <stdio.h>
int main(){
    double a,b; char op;
    if(scanf("%lf %c %lf",&a,&op,&b)!=3) return 0;
    switch(op){
        case '+': printf("%lf\n", a+b); break;
        case '-': printf("%lf\n", a-b); break;
        case '*': printf("%lf\n", a*b); break;
        case '/': if(b!=0) printf("%lf\n", a/b); else puts("Divide by zero"); break;
        default: puts("Unknown op");
    }
    return 0;
}

/*
39 - Queue using circular array
*/
#include <stdio.h>
#include <stdlib.h>
int main(){
    int n; scanf("%d",&n);
    int *q = malloc(n * sizeof *q);
    int head=0, tail=0, size=0;
    int cmd, val;
    while(scanf("%d",&cmd)==1){
        if(cmd==1){ scanf("%d",&val); if(size<n){ q[tail]=val; tail=(tail+1)%n; size++; } }
        else if(cmd==2){ if(size>0){ printf("%d\n", q[head]); head=(head+1)%n; size--; } }
        else break;
    }
    free(q);
    return 0;
}

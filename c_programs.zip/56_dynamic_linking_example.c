/*
56 - Dynamic library loading with dlopen (Linux)
Compile with -ldl
*/
#include <stdio.h>
#include <dlfcn.h>
int main(){
    void *h = dlopen("libm.so.6", RTLD_LAZY);
    if(!h){ puts("dlopen failed"); return 1; }
    double (*cosfptr)(double) = dlsym(h, "cos");
    printf("%f\n", cosfptr(0.0));
    dlclose(h);
    return 0;
}

/*
35 - Array of strings (array of pointers)
*/
#include <stdio.h>
int main(){
    const char *arr[] = {"apple","banana","cherry", NULL};
    for(int i=0; arr[i]; i++) puts(arr[i]);
    return 0;
}

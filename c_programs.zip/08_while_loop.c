/*
08 - While Loop
Prints first n natural numbers using while.
*/
#include <stdio.h>
int main() {
    int n; scanf("%d", &n);
    int i=1;
    while(i<=n) { printf("%d ", i); i++; }
    printf("\n");
    return 0;
}

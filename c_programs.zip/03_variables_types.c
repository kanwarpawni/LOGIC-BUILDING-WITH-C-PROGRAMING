/*
03 - Variables and Data Types
Demonstrates different variable types.
*/
#include <stdio.h>
int main() {
    int a = 10;
    float b = 3.14f;
    char c = 'A';
    double d = 2.71828;
    printf("int=%d float=%f char=%c double=%lf\n", a, b, c, d);
    return 0;
}

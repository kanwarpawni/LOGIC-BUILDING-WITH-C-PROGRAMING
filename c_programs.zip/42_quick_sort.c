/*
42 - Quick Sort (Lomuto)
*/
#include <stdio.h>
void qsort_rec(int a[], int l,int r){
    if(l<r){
        int p=a[r], i=l;
        for(int j=l;j<r;j++) if(a[j]<p){ int t=a[i]; a[i]=a[j]; a[j]=t; i++; }
        int t=a[i]; a[i]=a[r]; a[r]=t;
        qsort_rec(a,l,i-1); qsort_rec(a,i+1,r);
    }
}
int main(){ int n; scanf("%d",&n); int a[n]; for(int i=0;i<n;i++) scanf("%d",&a[i]); qsort_rec(a,0,n-1); for(int i=0;i<n;i++) printf("%d ", a[i]); printf("\n"); return 0; }

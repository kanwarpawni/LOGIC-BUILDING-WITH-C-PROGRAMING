/*
40 - Binary Tree: insert and preorder print (not balanced)
*/
#include <stdio.h>
#include <stdlib.h>
typedef struct Node{ int v; struct Node *l,*r; } Node;
Node* new(int v){ Node* n=malloc(sizeof *n); n->v=v;n->l=n->r=NULL; return n; }
Node* insert(Node* t,int v){ if(!t) return new(v); if(v<t->v) t->l=insert(t->l,v); else t->r=insert(t->r,v); return t; }
void preorder(Node* t){ if(!t) return; printf("%d ", t->v); preorder(t->l); preorder(t->r); }
int main(){ Node* root=NULL; int x; while(scanf("%d",&x)==1){ if(x==0) break; root=insert(root,x);} preorder(root); printf("\n"); return 0; }

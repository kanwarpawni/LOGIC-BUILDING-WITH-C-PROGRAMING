/*
33 - Command line arguments
Usage: ./a.out arg1 arg2
*/
#include <stdio.h>
int main(int argc, char **argv){
    printf("argc=%d\n", argc);
    for(int i=0;i<argc;i++) printf("%s\n", argv[i]);
    return 0;
}

/*
28 - Prime Check (simple)
*/
#include <stdio.h>
#include <math.h>
int main(){
    int n; scanf("%d",&n);
    if(n<=1){ puts("Not prime"); return 0; }
    for(int i=2;i<= (int)sqrt(n); i++) if(n%i==0){ puts("Not prime"); return 0; }
    puts("Prime");
    return 0;
}

/*
58 - Simple unit-test like main (manual)
*/
#include <stdio.h>
int add(int a,int b){ return a+b; }
int main(){
    if(add(2,3)==5) puts("PASS"); else puts("FAIL");
    return 0;
}

/*
16 - Dynamic Memory: allocate and free
*/
#include <stdio.h>
#include <stdlib.h>
int main(){
    int n; scanf("%d",&n);
    int *a = malloc(n * sizeof *a);
    for(int i=0;i<n;i++) scanf("%d",&a[i]);
    for(int i=0;i<n;i++) printf("%d ", a[i]);
    printf("\n");
    free(a);
    return 0;
}

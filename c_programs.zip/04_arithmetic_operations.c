/*
04 - Arithmetic Operations
Performs basic arithmetic on two integers.
*/
#include <stdio.h>
int main() {
    int a, b;
    printf("Enter two integers: ");
    if (scanf("%d %d", &a, &b)!=2) return 0;
    printf("Sum=%d\nDiff=%d\nProduct=%d\nQuotient=%d\nRemainder=%d\n", a+b, a-b, a*b, (b? a/b:0), (b? a%b:0));
    return 0;
}

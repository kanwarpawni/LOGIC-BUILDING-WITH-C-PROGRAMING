/*
50 - Binary File I/O: write and read array of ints
*/
#include <stdio.h>
int main(){
    int a[] = {1,2,3,4,5};
    FILE *f = fopen("data.bin","wb");
    fwrite(a, sizeof a[0], 5, f); fclose(f);
    int b[5];
    f = fopen("data.bin","rb");
    fread(b, sizeof b[0], 5, f); fclose(f);
    for(int i=0;i<5;i++) printf("%d ", b[i]); printf("\n");
    return 0;
}

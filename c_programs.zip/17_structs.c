/*
17 - Structs: student record
*/
#include <stdio.h>
typedef struct {
    char name[50];
    int id;
    float grade;
} Student;
int main(){
    Student s;
    scanf("%49s %d %f", s.name, &s.id, &s.grade);
    printf("Name:%s ID:%d Grade:%.2f\n", s.name, s.id, s.grade);
    return 0;
}

/*
38 - Stack using array
*/
#include <stdio.h>
#define MAX 100
int main(){
    int st[MAX], top=-1;
    int n;
    while(scanf("%d",&n)==1){
        if(n>0) st[++top]=n;
        else if(n==0 && top>=0) printf("Popped %d\n", st[top--]);
        else if(n<0) break;
    }
    return 0;
}

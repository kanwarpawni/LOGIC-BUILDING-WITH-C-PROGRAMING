/*
10 - Functions
Simple function to add two numbers.
*/
#include <stdio.h>
int add(int a,int b){return a+b;}
int main(){
    int x,y; scanf("%d %d",&x,&y);
    printf("%d\n", add(x,y));
    return 0;
}

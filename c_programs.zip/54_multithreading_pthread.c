/*
54 - Multithreading with pthreads (simple)
Compile: gcc -pthread 54_multithreading_pthread.c
*/
#include <stdio.h>
#include <pthread.h>
void* work(void* arg){ printf("Thread: %s\n", (char*)arg); return NULL; }
int main(){
    pthread_t t;
    pthread_create(&t, NULL, work, "hello");
    pthread_join(t, NULL);
    return 0;
}

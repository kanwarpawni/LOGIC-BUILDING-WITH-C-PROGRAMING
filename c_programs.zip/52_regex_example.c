/*
52 - Regex example using POSIX regex (advanced)
Compile with -std=c99 -Wall
*/
#include <stdio.h>
#include <regex.h>
int main(){
    regex_t re;
    regcomp(&re, "^[0-9]+$", REG_EXTENDED);
    char buf[100];
    fgets(buf, sizeof buf, stdin); buf[strcspn(buf,"\n")]=0;
    int ok = regexec(&re, buf, 0, NULL, 0) == 0;
    puts(ok? "All digits":"Not all digits");
    regfree(&re);
    return 0;
}

C Programs Collection - 60 examples
Each file is named NN_description.c
Compile using gcc filename.c -o output
Some files may need extra flags as mentioned in comments.

/*
30 - Bitwise Operations demo
*/
#include <stdio.h>
int main(){
    unsigned int a,b; scanf("%u %u",&a,&b);
    printf("AND=%u OR=%u XOR=%u NOT_a=%u\n", a&b, a|b, a^b, ~a);
    return 0;
}

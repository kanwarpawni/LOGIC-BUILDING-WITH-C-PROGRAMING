/*
09 - Do While Loop
Accepts numbers until user enters 0; prints sum.
*/
#include <stdio.h>
int main() {
    int x; int sum=0;
    do {
        scanf("%d", &x);
        sum += x;
    } while(x!=0);
    printf("Sum=%d\n", sum);
    return 0;
}

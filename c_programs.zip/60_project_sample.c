/*
60 - Sample mini project: simple text statistics
Reads input and prints number of lines, words, and characters.
*/
#include <stdio.h>
#include <ctype.h>
int main(){
    int c, nc=0,nw=0,nl=0;
    int inword=0;
    while((c=getchar())!=EOF){
        nc++;
        if(c=='\n') nl++;
        if(isspace(c)) inword=0;
        else if(!inword){ inword=1; nw++; }
    }
    printf("Lines=%d Words=%d Chars=%d\n", nl, nw, nc);
    return 0;
}

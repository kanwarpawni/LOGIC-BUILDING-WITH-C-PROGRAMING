/*
18 - File I/O: write and read a file
*/
#include <stdio.h>
int main(){
    FILE *f = fopen("sample.txt","w");
    if(!f) return 1;
    fprintf(f, "Hello from C file I/O\n");
    fclose(f);
    f = fopen("sample.txt","r");
    if(!f) return 1;
    char buf[200];
    while(fgets(buf, sizeof buf, f)) fputs(buf, stdout);
    fclose(f);
    return 0;
}

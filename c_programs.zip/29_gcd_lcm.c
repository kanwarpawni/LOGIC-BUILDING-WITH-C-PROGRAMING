/*
29 - GCD and LCM using Euclid
*/
#include <stdio.h>
int gcd(int a,int b){ return b==0? a: gcd(b, a%b); }
int main(){ int a,b; scanf("%d %d",&a,&b); int g=gcd(a,b); printf("GCD=%d LCM=%d\n", g, a/g*b); return 0; }

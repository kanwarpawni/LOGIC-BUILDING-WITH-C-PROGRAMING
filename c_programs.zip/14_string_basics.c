/*
14 - Strings: length, copy (using library)
*/
#include <stdio.h>
#include <string.h>
int main(){
    char s[200];
    fgets(s,200,stdin);
    s[strcspn(s,"\n")]=0;
    printf("Length=%zu\nCopy=%s\n", strlen(s), s);
    return 0;
}

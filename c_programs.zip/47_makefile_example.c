/*
47 - Makefile example is not code; this file shows contents of a simple Makefile as comment.
*/
#include <stdio.h>
int main(){ puts("See Makefile in comments of this file."); return 0; }
/*
Makefile:
all:
\tgcc 47_makefile_example.c -o example
*/

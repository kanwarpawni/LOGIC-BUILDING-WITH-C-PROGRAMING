/*
48 - Sort array of structs by field
*/
#include <stdio.h>
#include <string.h>
typedef struct { int id; char name[50]; } Item;
int cmp(const void *a,const void *b){ return ((Item*)a)->id - ((Item*)b)->id; }
int main(){
    int n; scanf("%d",&n);
    Item a[n];
    for(int i=0;i<n;i++) scanf("%d %49s",&a[i].id,a[i].name);
    qsort(a,n,sizeof *a, cmp);
    for(int i=0;i<n;i++) printf("%d %s\n", a[i].id, a[i].name);
    return 0;
}

/*
26 - Check Palindrome (string)
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(){
    char s[500]; fgets(s,500,stdin); s[strcspn(s,"\n")]=0;
    int i=0,j=strlen(s)-1; int ok=1;
    while(i<j){ while(i<j && !isalnum((unsigned char)s[i])) i++;
                 while(i<j && !isalnum((unsigned char)s[j])) j--;
                 if(tolower((unsigned char)s[i])!=tolower((unsigned char)s[j])) { ok=0; break; }
                 i++; j--; }
    puts(ok? "Palindrome":"Not Palindrome");
    return 0;
}

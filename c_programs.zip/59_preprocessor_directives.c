/*
59 - Preprocessor directives demo
*/
#include <stdio.h>
#define FEATURE 1
int main(){
#ifdef FEATURE
    puts("Feature enabled");
#else
    puts("Feature disabled");
#endif
    return 0;
}

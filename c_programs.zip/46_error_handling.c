/*
46 - Simple error handling example: fopen
*/
#include <stdio.h>
int main(){
    FILE *f = fopen("does_not_exist.txt","r");
    if(!f){ perror("fopen"); return 1; }
    fclose(f);
    return 0;
}

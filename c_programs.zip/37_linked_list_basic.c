/*
37 - Singly Linked List: insert at front and print
*/
#include <stdio.h>
#include <stdlib.h>
typedef struct Node { int val; struct Node *next; } Node;
void push(Node **head,int v){ Node *n = malloc(sizeof *n); n->val=v; n->next=*head; *head=n; }
void printall(Node *h){ while(h){ printf("%d ", h->val); h=h->next; } printf("\n"); }
int main(){
    Node *head = NULL; int x;
    while(scanf("%d",&x)==1){ if(x==0) break; push(&head,x); }
    printall(head);
    return 0;
}

/*
51 - Time functions: measure elapsed time
Compile with -std=c99
*/
#include <stdio.h>
#include <time.h>
int main(){
    clock_t s = clock();
    for(volatile long i=0;i<10000000;i++);
    clock_t e = clock();
    printf("Elapsed sec=%.6f\n", (double)(e-s)/CLOCKS_PER_SEC);
    return 0;
}

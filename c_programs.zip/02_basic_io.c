/*
02 - Basic Input/Output
Reads an integer and prints it.
*/
#include <stdio.h>
int main() {
    int n;
    printf("Enter an integer: ");
    if (scanf("%d", &n)==1) printf("You entered: %d\n", n);
    return 0;
}

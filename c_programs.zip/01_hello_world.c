/*
01 - Hello World
Compile: gcc 01_hello_world.c -o hello
Run: ./hello
*/
#include <stdio.h>
int main() {
    printf("Hello, World!\n");
    return 0;
}

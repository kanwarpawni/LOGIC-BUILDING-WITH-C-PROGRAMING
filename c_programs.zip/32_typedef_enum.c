/*
32 - typedef and enum
*/
#include <stdio.h>
typedef enum { RED, GREEN, BLUE } Color;
int main(){
    Color c = GREEN;
    printf("%d\n", c);
    return 0;
}

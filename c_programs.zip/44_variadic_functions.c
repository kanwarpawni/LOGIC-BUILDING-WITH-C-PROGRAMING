/*
44 - Variadic function: sum of integers
Compile with -std=c99
*/
#include <stdio.h>
#include <stdarg.h>
int sum(int count, ...){
    va_list ap; va_start(ap, count);
    int s=0;
    for(int i=0;i<count;i++) s += va_arg(ap, int);
    va_end(ap);
    return s;
}
int main(){ printf("%d\n", sum(4,1,2,3,4)); return 0; }

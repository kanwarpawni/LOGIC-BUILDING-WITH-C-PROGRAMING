/*
57 - Memory leak demo (intentional for teaching)
*/
#include <stdlib.h>
int main(){
    for(int i=0;i<1000;i++) malloc(1024);
    return 0;
}

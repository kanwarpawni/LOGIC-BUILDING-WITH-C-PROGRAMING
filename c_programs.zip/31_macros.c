/*
31 - Macros and Constants
*/
#include <stdio.h>
#define SQR(x) ((x)*(x))
int main(){
    int n; scanf("%d",&n);
    printf("Square=%d\n", SQR(n));
    return 0;
}

/*
36 - Dynamic 2D array using malloc
*/
#include <stdio.h>
#include <stdlib.h>
int main(){
    int r,c; scanf("%d %d",&r,&c);
    int **a = malloc(r * sizeof *a);
    for(int i=0;i<r;i++){ a[i]=malloc(c * sizeof *a[i]); for(int j=0;j<c;j++) scanf("%d",&a[i][j]); }
    for(int i=0;i<r;i++){ for(int j=0;j<c;j++) printf("%d ", a[i][j]); printf("\n"); }
    for(int i=0;i<r;i++) free(a[i]);
    free(a);
    return 0;
}
